<footer class="fixed-bottom py-3 bg-light mt-auto">
            <div class="container text-center">
                <p>Created by <a href="#">Mahasiswa NF &copy;2024</p>
            </div>
        </footer>
    </div>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>

</html> 