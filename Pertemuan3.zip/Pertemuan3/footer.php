<footer class="text-center py-3 bg-light mt-5">
        <p>Created by <a href="#">Nursalsabilah</a> &copy; <?php echo date('Y') ?></p>
    </footer>
</body>

</html>