
<?php
include_once 'header.php' ;
?>

				<h1>Welcome Home!</h1>
				<p> Nama: Nursalsabilah</p>
                <p> Nim: 0110123259</p>
                <p> Rombel: SI07 </p>
               
          <?php
include_once 'footer.php' ;
?>